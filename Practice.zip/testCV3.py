# -*- coding: utf-8 -*-
"""
Created on Mon Oct  1 09:42:49 2018

@author: Coco
"""

import numpy as np
import cv2
from matplotlib import pyplot as plt

# Load an color image in grayscale
img = cv2.imread('coins.jpg',0)
plt.imshow(img,cmap = 'gray')
ret,thresh1 = cv2.threshold(img,200,255,cv2.THRESH_BINARY)
plt.figure()
thresh1=255-thresh1
plt.imshow(thresh1,cmap = 'gray')

kernel = np.ones((5,5),np.uint8)
erosion = cv2.erode(thresh1,kernel,iterations = 1)
dilation = cv2.dilate(thresh1,kernel,iterations = 1)
opening = cv2.morphologyEx(thresh1, cv2.MORPH_OPEN, kernel)
closing = cv2.morphologyEx(thresh1, cv2.MORPH_CLOSE, kernel)
plt.figure()
plt.subplot(221)
plt.imshow(erosion,cmap = 'gray')
plt.subplot(222)
plt.imshow(dilation,cmap = 'gray')
plt.subplot(223)
plt.imshow(opening,cmap = 'gray')
plt.subplot(224)
plt.imshow(closing,cmap = 'gray')

